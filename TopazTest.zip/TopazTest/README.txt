Diretório do projeto .\Test
Utilizado Java 1.8 e JUnit4
Arquivos em .\Test\src\br\com\topaz\server
	Balancer.java
	Engine.java
	Server.java
	Solution.java - contém o método Main para ser executado
Arquivos de unit test em .\Test\src\br\com\topaz\server
	TestBalancer.java
	TestEngine.java
	TestServer.java