package br.com.topaz.test;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;

import br.com.topaz.server.Engine;

public class TestEngine {

	// testa o exemplo dado no enunciado do teste
	@org.junit.Test
	public void testEngine1() {
		List<Integer> inputIntegerList = new ArrayList<Integer>();
		inputIntegerList.add(4);
		inputIntegerList.add(2);
		inputIntegerList.add(1);
		inputIntegerList.add(3);
		inputIntegerList.add(0);
		inputIntegerList.add(1);
		inputIntegerList.add(0);
		inputIntegerList.add(1);
		List<String> outputStringList = Engine.processInput(inputIntegerList);
		List<String> expectedOutputStringList = new ArrayList<String>();
		// tick=1;newUsers=1
		// ini: [4,0]
		// fim: [3,0]
		expectedOutputStringList.add("1");
		// tick=2;newUsers=3
		// ini: [3,4];[4,4]
		// fim: [2,3];[3,3]
		expectedOutputStringList.add("2,2");
		// tick=3;newUsers=0
		// ini: [2,3];[3,3]
		// fim: [1,2];[2,2]
		expectedOutputStringList.add("2,2");
		// tick=4;newUsers=1
		// ini: [1,2];[2,2];[4,0]
		// fim: [0,1];[1,1];[3,0]
		expectedOutputStringList.add("2,2,1");
		// tick=5;newUsers=0
		// ini: [0,1];[1,1];[3,0]
		// fim: [0,0];[0,0];[2,0]
		expectedOutputStringList.add("1,2,1");
		// tick=6;newUsers=1
		// ini: [2,4]
		// fim: [1,3]
		expectedOutputStringList.add("2");
		// tick=7
		// ini: [1,3]
		// fim: [0,2]
		expectedOutputStringList.add("2");
		// tick=8
		// ini: [0,2]
		// fim: [0,1]
		expectedOutputStringList.add("1");
		// tick=9
		// ini: [0,1]
		// fim: [0,0]
		expectedOutputStringList.add("1");
		// tick=10
		// ini: nenhum servidor
		// fim: nenhum servidor
		expectedOutputStringList.add("0");
		expectedOutputStringList.add("15");
		Assert.assertEquals(expectedOutputStringList, outputStringList);
	}

	// testa um exemplo a mais
	@org.junit.Test
	public void testEngine2() {
		List<Integer> inputIntegerList = new ArrayList<Integer>();
		inputIntegerList.add(4);
		inputIntegerList.add(4);
		inputIntegerList.add(1);
		inputIntegerList.add(3);
		inputIntegerList.add(0);
		inputIntegerList.add(1);
		inputIntegerList.add(3);
		inputIntegerList.add(1);
		List<String> outputStringList = Engine.processInput(inputIntegerList);
		List<String> expectedOutputStringList = new ArrayList<String>();
		// tick=1;newUsers=1
		// ini: [4,0,0,0]
		// fim: [3,0,0,0]
		expectedOutputStringList.add("1");
		// tick=2;newUsers=3
		// ini: [3,4,4,4]
		// fim: [2,3,3,3]
		expectedOutputStringList.add("4");
		// tick=3;newUsers=0
		// ini: [2,3,3,3]
		// fim: [1,2,2,2]
		expectedOutputStringList.add("4");
		// tick=4;newUsers=1
		// ini: [1,2,2,2];[4,0,0,0]
		// fim: [0,1,1,1];[3,0,0,0]
		expectedOutputStringList.add("4,1");
		// tick=5;newUsers=3
		// ini: [0,1,1,1];[3,4,4,4]
		// fim: [0,0,0,0];[2,3,3,3]
		expectedOutputStringList.add("3,4");
		// tick=6;newUsers=1
		// ini: [2,3,3,3];[4,0,0,0]
		// fim: [1,2,2,2];[3,0,0,0]
		expectedOutputStringList.add("4,1");
		// tick=7
		// ini: [1,2,2,2];[3,0,0,0]
		// fim: [0,1,1,1];[2,0,0,0]
		expectedOutputStringList.add("4,1");
		// tick=8
		// ini: [0,1,1,1];[2,0,0,0]
		// fim: [0,0,0,0];[1,0,0,0]
		expectedOutputStringList.add("3,1");
		// tick=9
		// ini: [0,0,0,0];[1,0,0,0]
		// fim: [0,0,0,0];[0,0,0,0]
		expectedOutputStringList.add("1");
		// tick=10
		// ini: nenhum servidor
		// fim: nenhum servidor
		expectedOutputStringList.add("0");
		expectedOutputStringList.add("14");
		Assert.assertEquals(expectedOutputStringList, outputStringList);
	}

	// testa um exemplo a mais
	@org.junit.Test
	public void testEngine3() {
		List<Integer> inputIntegerList = new ArrayList<Integer>();
		inputIntegerList.add(4);
		inputIntegerList.add(4);
		inputIntegerList.add(1);
		inputIntegerList.add(3);
		inputIntegerList.add(0);
		inputIntegerList.add(1);
		inputIntegerList.add(4);
		inputIntegerList.add(1);
		List<String> outputStringList = Engine.processInput(inputIntegerList);
		List<String> expectedOutputStringList = new ArrayList<String>();
		// tick=1;newUsers=1
		// ini: [4,0,0,0]
		// fim: [3,0,0,0]
		expectedOutputStringList.add("1");
		// tick=2;newUsers=3
		// ini: [3,4,4,4]
		// fim: [2,3,3,3]
		expectedOutputStringList.add("4");
		// tick=3;newUsers=0
		// ini: [2,3,3,3]
		// fim: [1,2,2,2]
		expectedOutputStringList.add("4");
		// tick=4;newUsers=1
		// ini: [1,2,2,2];[4,0,0,0]
		// fim: [0,1,1,1];[3,0,0,0]
		expectedOutputStringList.add("4,1");
		// tick=5;newUsers=4
		// ini: [4,1,1,1];[3,4,4,4]
		// fim: [3,0,0,0];[2,3,3,3]
		expectedOutputStringList.add("4,4");
		// tick=6;newUsers=1
		// ini: [3,4,0,0];[2,3,3,3]
		// fim: [2,3,0,0];[1,2,2,2]
		expectedOutputStringList.add("2,4");
		// tick=7
		// ini: [2,3,0,0];[1,2,2,2]
		// fim: [1,2,0,0];[0,1,1,1]
		expectedOutputStringList.add("2,4");
		// tick=8
		// ini: [1,2,0,0];[0,1,1,1]
		// fim: [0,1,0,0];[0,0,0,0]
		expectedOutputStringList.add("2,3");
		// tick=9
		// ini: [0,1,0,0]
		// fim: [0,0,0,0]
		expectedOutputStringList.add("1");
		// tick=10
		// ini: nenhum servidor
		// fim: nenhum servidor
		expectedOutputStringList.add("0");
		expectedOutputStringList.add("14");
		Assert.assertEquals(expectedOutputStringList, outputStringList);
	}

}
