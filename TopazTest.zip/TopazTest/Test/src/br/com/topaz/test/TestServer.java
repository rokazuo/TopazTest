package br.com.topaz.test;

import org.junit.Assert;

import br.com.topaz.server.Server;

// Testa a classe Server
public class TestServer {

	// testa se o servidor n�o tem usu�rio conectado
	@org.junit.Test
	public void testHasNoUser() {
		Server server = new Server(4, 2);
		Assert.assertEquals(true, server.hasNoUser());
	}

	// testa se o servidor tem usu�rio conectado
	@org.junit.Test
	public void testHasUser() {
		Server server = new Server(4, 2);
		server.allocateUser(1);
		Assert.assertEquals(false, server.hasNoUser());
	}

	// testa a aloca��o do de um novo usu�rio um por vez
	@org.junit.Test
	public void testAllocateUserOneByOne() {
		Server server = new Server(4, 2);
		server.allocateUser(1);
		server.allocateUser(1);
		Assert.assertEquals(2, server.getNumberOfActiveUser());
	}

	// testa o retorno do tempo de vida restante do servidor
	@org.junit.Test
	public void testRemainingTimeLife() {
		Server server = new Server(4, 2);
		server.allocateUser(1);
		Assert.assertEquals(4, server.getRemainingTimeLife());
	}

	// testa a funcionalidade do m�todo work
	@org.junit.Test
	public void testWork() {
		Server server = new Server(4, 2);
		server.allocateUser(1);
		Assert.assertEquals(4, server.getRemainingTimeLife());
		Assert.assertEquals(0, server.getCost());
		server.work();
		Assert.assertEquals(3, server.getRemainingTimeLife());
		Assert.assertEquals(1, server.getCost());
		server.work();
		Assert.assertEquals(2, server.getRemainingTimeLife());
		Assert.assertEquals(2, server.getCost());
		server.work();
		Assert.assertEquals(1, server.getRemainingTimeLife());
		Assert.assertEquals(3, server.getCost());
		server.work();
		Assert.assertEquals(0, server.getRemainingTimeLife());
		Assert.assertEquals(4, server.getCost());
	}

	// testa o retorno da quantidade de vagas livres no servidor
	@org.junit.Test
	public void testNumberOfEmptySlot() {
		Server server = new Server(4, 2);
		server.allocateUser(1);
		Assert.assertEquals(1, server.getNumberOfEmptySlot());
		server.allocateUser(1);
		Assert.assertEquals(0, server.getNumberOfEmptySlot());
	}

	// testa o retorno da quantidade de usu�rios ativos no servidor
	@org.junit.Test
	public void testNumberOfActiveUser() {
		Server server = new Server(4, 2);
		server.allocateUser(1);
		Assert.assertEquals(1, server.getNumberOfActiveUser());
		server.allocateUser(1);
		Assert.assertEquals(2, server.getNumberOfActiveUser());
	}

	// testa o custo do servidor
	@org.junit.Test
	public void testCost() {
		Server server = new Server(4, 2);
		server.allocateUser(1);
		server.work();
		server.allocateUser(1);
		server.work();
		server.work();
		server.work();
		server.work();
		// as chamadas abaixo do m�todo work n�o deve aumentar o custo do
		// servidor
		server.work();
		server.work();
		server.work();
		Assert.assertEquals(5, server.getCost());
	}
}
