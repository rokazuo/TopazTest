package br.com.topaz.test;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;

import br.com.topaz.server.Balancer;
import br.com.topaz.server.Server;

//Testa a classe Balancer
public class TestBalancer {

	// testa a aloca��o de novos usu�rios a novos servidores
	@org.junit.Test
	public void testAllocateUserInNewServer() {
		List<Server> serverList = new ArrayList<Server>();
		Balancer balancer = new Balancer(4, 2);
		balancer.allocateUserInNewServers(3, serverList);
		Assert.assertEquals(2, serverList.size());
		Assert.assertEquals(2, serverList.get(0).getNumberOfActiveUser());
		Assert.assertEquals(1, serverList.get(1).getNumberOfActiveUser());
	}

	// testa a aloca��o de novos usu�rios a novos servidores
	// pelo m�todo allocateUsers
	@org.junit.Test
	public void testAllocateUsersInNewServer() {
		List<Server> serverList = new ArrayList<Server>();
		Balancer balancer = new Balancer(4, 2);
		balancer.allocateUsers(3, serverList);
		Assert.assertEquals(2, serverList.size());
		Assert.assertEquals(2, serverList.get(0).getNumberOfActiveUser());
		Assert.assertEquals(1, serverList.get(1).getNumberOfActiveUser());
	}

	// testa o m�todo getServeCandidateList
	@org.junit.Test
	public void testGetServerCandidateList() {
		int ttask = 4;
		int umax = 4;
		List<Server> serverList = populateServerList(ttask, umax);
		// [1,2,0,0]
		// [2,2,0,0]
		// [4,0,0,0]
		// [4,4,4,0]
		// [4,4,0,0]
		// [3,4,0,0]
		// [4,4,4,4]
		Balancer balancer = new Balancer(ttask, umax);
		List<Server> serverCandidateList = balancer.getServeCandidateList(1,
				serverList);
		Assert.assertEquals(4, serverCandidateList.size());
		// [4,4,4,0]
		Assert.assertEquals(serverCandidateList.get(0), serverList.get(3));
		// [3,4,0,0]
		Assert.assertEquals(serverCandidateList.get(1), serverList.get(5));
		// [4,4,0,0]
		Assert.assertEquals(serverCandidateList.get(2), serverList.get(4));
		// [4,0,0,0]
		Assert.assertEquals(serverCandidateList.get(3), serverList.get(2));
		Assert.assertEquals(8, balancer.getTotalNumberOfCadidateEmptySlot());
	}

	// testa o m�todo getServeCandidateList
	@org.junit.Test
	public void testGetServerCandidateList2() {
		int ttask = 4;
		int umax = 4;
		List<Server> serverList = populateServerList2(ttask, umax);
		// [4,4,4,0]
		// [4,4,0,0]
		// [4,0,0,0]
		Balancer balancer = new Balancer(ttask, umax);
		List<Server> serverCandidateList = balancer.getServeCandidateList(1,
				serverList);
		Assert.assertEquals(3, serverCandidateList.size());
		// [4,4,4,0]
		Assert.assertEquals(serverCandidateList.get(0), serverList.get(0));
		// [4,4,0,0]
		Assert.assertEquals(serverCandidateList.get(1), serverList.get(1));
		// [4,0,0,0]
		Assert.assertEquals(serverCandidateList.get(2), serverList.get(2));
		Assert.assertEquals(6, balancer.getTotalNumberOfCadidateEmptySlot());
	}

	// testa o m�todo getServeCandidateList
	@org.junit.Test
	public void testGetServerCandidateList3() {
		int ttask = 4;
		int umax = 4;
		List<Server> serverList = populateServerList3(ttask, umax);
		// [0,1,1,1]
		// [4,0,0,0]
		// [3,0,0,0]
		Balancer balancer = new Balancer(ttask, umax);
		List<Server> serverCandidateList = balancer.getServeCandidateList(3,
				serverList);
		Assert.assertEquals(1, serverCandidateList.size());
		// [4,0,0,0]
		Assert.assertEquals(serverCandidateList.get(0), serverList.get(1));
	}

	// testa o m�todo balanceUsersInServers indiretamente pelo m�todo
	// allocateUsersInCurrentServers
	@org.junit.Test
	public void testBalanceServer1() {
		int ttask = 4;
		int umax = 4;
		List<Server> serverList = populateServerList2(ttask, umax);
		// [4,4,4,0]
		// [4,4,0,0]
		// [4,0,0,0]
		Balancer balancer = new Balancer(ttask, umax);
		int numberOfAllocatedUsers = balancer.allocateUsersInCurrentServers(4,
				serverList);
		Assert.assertEquals(4, numberOfAllocatedUsers);
		// [4,4,4,0]
		Assert.assertEquals(1, serverList.get(0).getNumberOfEmptySlot());
		// [4,4,4,0]
		Assert.assertEquals(1, serverList.get(1).getNumberOfEmptySlot());
		// [4,4,4,4]
		Assert.assertEquals(0, serverList.get(2).getNumberOfEmptySlot());
	}

	// testa o m�todo balanceUsersInServers indiretamente pelo m�todo
	// allocateUsersInCurrentServers
	@org.junit.Test
	public void testBalanceServer2() {
		int ttask = 4;
		int umax = 4;
		List<Server> serverList = populateServerList2(ttask, umax);
		// [4,4,4,0]
		// [4,4,0,0]
		// [4,0,0,0]
		Balancer balancer = new Balancer(ttask, umax);
		int numberOfAllocatedUsers = balancer.allocateUsersInCurrentServers(3,
				serverList);
		Assert.assertEquals(3, numberOfAllocatedUsers);
		// [4,4,4,0]
		Assert.assertEquals(1, serverList.get(0).getNumberOfEmptySlot());
		// [4,4,4,0]
		Assert.assertEquals(1, serverList.get(1).getNumberOfEmptySlot());
		// [4,4,4,0]
		Assert.assertEquals(1, serverList.get(2).getNumberOfEmptySlot());
	}

	// testa o m�todo balanceUsersInServers indiretamente pelo m�todo
	// allocateUsersInCurrentServers
	@org.junit.Test
	public void testBalanceServer3() {
		int ttask = 4;
		int umax = 4;
		List<Server> serverList = populateServerList2(ttask, umax);
		// [4,4,4,0]
		// [4,4,0,0]
		// [4,0,0,0]
		Balancer balancer = new Balancer(ttask, umax);
		int numberOfAllocatedUsers = balancer.allocateUsersInCurrentServers(2,
				serverList);
		Assert.assertEquals(2, numberOfAllocatedUsers);
		// [4,4,4,0]
		Assert.assertEquals(1, serverList.get(0).getNumberOfEmptySlot());
		// [4,4,0,0]
		Assert.assertEquals(2, serverList.get(1).getNumberOfEmptySlot());
		// [4,4,4,0]
		Assert.assertEquals(1, serverList.get(2).getNumberOfEmptySlot());
	}

	// testa o m�todo balanceUsersInServers indiretamente pelo m�todo
	// allocateUsersInCurrentServers
	@org.junit.Test
	public void testBalanceServer4() {
		int ttask = 4;
		int umax = 4;
		List<Server> serverList = populateServerList2(ttask, umax);
		// [4,4,4,0]
		// [4,4,0,0]
		// [4,0,0,0]
		Balancer balancer = new Balancer(ttask, umax);
		int numberOfAllocatedUsers = balancer.allocateUsersInCurrentServers(1,
				serverList);
		Assert.assertEquals(1, numberOfAllocatedUsers);
		// [4,4,4,0]
		Assert.assertEquals(1, serverList.get(0).getNumberOfEmptySlot());
		// [4,4,0,0]
		Assert.assertEquals(2, serverList.get(1).getNumberOfEmptySlot());
		// [4,4,0,0]
		Assert.assertEquals(2, serverList.get(2).getNumberOfEmptySlot());
	}

	// testa o m�todo allocateUsers
	@org.junit.Test
	public void testBalanceServer5() {
		int ttask = 4;
		int umax = 4;
		List<Server> serverList = populateServerList4(ttask, umax);
		// [0,1,1,1]
		// [3,0,0,0]
		Balancer balancer = new Balancer(ttask, umax);
		balancer.allocateUsers(4, serverList);
		// [4,1,1,1]
		Assert.assertEquals(0, serverList.get(0).getNumberOfEmptySlot());
		// [3,4,4,4]
		Assert.assertEquals(0, serverList.get(1).getNumberOfEmptySlot());
	}

	private List<Server> populateServerList(int ttask, int umax) {
		List<Server> serverList = new ArrayList<Server>();
		Server server1 = new Server(ttask, umax);
		server1.allocateUser(1);
		// [3,0,0,0]
		server1.work();
		server1.allocateUser(1);
		// [2,3,0,0]
		server1.work();
		// [1,2,0,0]
		server1.work();
		serverList.add(server1);

		Server server2 = new Server(ttask, umax);
		server2.allocateUser(2);
		// [3,3,0,0]
		server2.work();
		// [2,2,0,0]
		server2.work();
		serverList.add(server2);

		Server server3 = new Server(ttask, umax);
		// [4,0,0,0]
		server3.allocateUser(1);
		serverList.add(server3);

		Server server4 = new Server(ttask, umax);
		// [4,4,4,0]
		server4.allocateUser(3);
		serverList.add(server4);

		Server server5 = new Server(ttask, umax);
		// [4,4,0,0]
		server5.allocateUser(2);
		serverList.add(server5);

		Server server6 = new Server(ttask, umax);
		server6.allocateUser(1);
		// [3,0,0,0]
		server6.work();
		// [3,4,0,0]
		server6.allocateUser(1);
		serverList.add(server6);

		Server server7 = new Server(ttask, umax);
		// [4,4,4,4]
		server7.allocateUser(umax);
		serverList.add(server7);

		// [1,2,0,0]
		// [2,2,0,0]
		// [4,0,0,0]
		// [4,4,4,0]
		// [4,4,0,0]
		// [3,4,0,0]
		// [4,4,4,4]
		return serverList;
	}

	private List<Server> populateServerList2(int ttask, int umax) {
		List<Server> serverList = new ArrayList<Server>();

		Server server1 = new Server(ttask, umax);
		// [4,4,4,0]
		server1.allocateUser(3);
		serverList.add(server1);

		Server server2 = new Server(ttask, umax);
		// [4,4,0,0]
		server2.allocateUser(2);
		serverList.add(server2);

		Server server3 = new Server(ttask, umax);
		// [4,0,0,0]
		server3.allocateUser(1);
		serverList.add(server3);

		// [4,4,4,0]
		// [4,4,0,0]
		// [4,0,0,0]
		return serverList;
	}

	private List<Server> populateServerList3(int ttask, int umax) {
		List<Server> serverList = new ArrayList<Server>();

		Server server1 = new Server(ttask, umax);
		// [4,0,0,0]
		server1.allocateUser(1);
		// [3,0,0,0]
		server1.work();
		// [3,4,4,4]
		server1.allocateUser(3);
		// [2,3,3,3]
		server1.work();
		// [1,2,2,2]
		server1.work();
		// [0,1,1,1]
		server1.work();
		serverList.add(server1);

		Server server2 = new Server(ttask, umax);
		// [4,0,0,0]
		server2.allocateUser(1);
		// [3,0,0,0]
		server2.work();
		serverList.add(server2);

		// [0,1,1,1]
		// [4,0,0,0]
		// [3,0,0,0]
		return serverList;
	}

	private List<Server> populateServerList4(int ttask, int umax) {
		List<Server> serverList = new ArrayList<Server>();

		Server server1 = new Server(ttask, umax);
		// [4,0,0,0]
		server1.allocateUser(1);
		// [3,0,0,0]
		server1.work();
		// [3,4,4,4]
		server1.allocateUser(3);
		// [2,3,3,3]
		server1.work();
		// [1,2,2,2]
		server1.work();
		// [0,1,1,1]
		server1.work();
		serverList.add(server1);

		Server server2 = new Server(ttask, umax);
		// [4,0,0,0]
		server2.allocateUser(1);
		// [4,0,0,0]
		server2.work();
		serverList.add(server2);

		// [0,1,1,1]
		// [3,0,0,0]
		return serverList;
	}
}
