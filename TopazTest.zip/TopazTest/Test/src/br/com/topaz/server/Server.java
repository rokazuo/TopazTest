package br.com.topaz.server;

import java.util.ArrayList;
import java.util.List;

/**
 * Classe que representa o servidor e concentrar� todas as funcionalidades e
 * propriedades do mesmo
 * 
 */
public class Server {
	// lista dos usu�rios conectados ao servidor com o tempo de vida
	// restante dentro do servidor
	List<Integer> userRemainingTimeLifeList = new ArrayList<Integer>();
	// custo do servidor
	int cost = 0;
	// custo de uma tarefa a ser executada no servidor
	int ttask = 0;

	/**
	 * Construtor da classe Servidor
	 * 
	 * @param ttask
	 *            custo de uma tarefa no servidor
	 * 
	 * @param umax
	 *            quantidade m�xima de usu�rios por servidor
	 * 
	 */
	public Server(int ttask, int umax) {
		this.ttask = ttask;
		for (int i = 0; i < umax; i++) {
			userRemainingTimeLifeList.add(0);
		}
	}

	/**
	 * Retorna o tempo de vida restante deste servidor
	 * 
	 * @return tempo de vida restante do servidor
	 */
	public int getRemainingTimeLife() {
		int maxUserTimeLife = 0;
		for (Integer userRemainingTimeLife : userRemainingTimeLifeList) {
			if (userRemainingTimeLife > maxUserTimeLife) {
				maxUserTimeLife = userRemainingTimeLife;
			}
		}
		return maxUserTimeLife;
	}

	/**
	 * Retorna a quantidade de vagas livres para novos usu�rios
	 * 
	 * @return quantidade de vagas livres para novos usu�rios
	 */
	public int getNumberOfEmptySlot() {
		int numberOfEmptySlotRetVal = 0;
		for (Integer userRemainingTimeLife : userRemainingTimeLifeList) {
			if (userRemainingTimeLife == 0) {
				numberOfEmptySlotRetVal++;
			}
		}
		return numberOfEmptySlotRetVal;
	}

	/**
	 * Realiza as tarefas desse servidor que � decrementar em uma unidade o
	 * tempo de vida de um usu�rio e incrementar o custo do servidor por tick
	 * (unidade b�sica de simula��o no servidor)
	 */
	public void work() {
		boolean hasDecrementedTimelife = false;
		for (int i = 0; i < userRemainingTimeLifeList.size(); i++) {
			int userRemainingTimeLife = userRemainingTimeLifeList.get(i);
			if (userRemainingTimeLife > 0) {
				userRemainingTimeLifeList.set(i, userRemainingTimeLife - 1);
				hasDecrementedTimelife = true;
			}
		}
		if (hasDecrementedTimelife) {
			cost++;
		}

	}

	/**
	 * Indica se n�o tem usu�rio conectado no servidor
	 * 
	 * @return true se n�o tiver usu�rio ativo no servidor, caso contr�rio,
	 *         false
	 */
	public boolean hasNoUser() {
		boolean hasNoUserRetVal = true;
		for (Integer userRemainingTimeLife : userRemainingTimeLifeList) {
			if (userRemainingTimeLife > 0) {
				hasNoUserRetVal = false;
				break;
			}
		}
		return hasNoUserRetVal;
	}

	/**
	 * Indica a quantidade de usu�rio ativos dentro do servidor
	 * 
	 * @return quantidade de usu�rios conectado ao sevidor
	 */
	public int getNumberOfActiveUser() {
		int numberOfActiveUser = 0;
		for (Integer userRemainingTimeLife : userRemainingTimeLifeList) {
			if (userRemainingTimeLife > 0) {
				numberOfActiveUser++;
			}
		}
		return numberOfActiveUser;
	}

	/**
	 * Aloca um novo usu�rio dentro do servidor Cada usu�rio novo � representado
	 * numa lista de usu�rios alocando inicialmente com um tempo de vida
	 * restante de ttask, que � o custo de uma tarefa que ser� executado por
	 * esse usu�rio.
	 */
	public void allocateUser(int numberOfUserToAlloc) {
		if (numberOfUserToAlloc == 0
				|| numberOfUserToAlloc > getNumberOfEmptySlot()) {
			return;
		}
		for (int i = 0; i < userRemainingTimeLifeList.size(); i++) {
			if (userRemainingTimeLifeList.get(i) == 0) {
				userRemainingTimeLifeList.set(i, ttask);
				numberOfUserToAlloc--;
			}
			if (numberOfUserToAlloc == 0) {
				break;
			}
		}
	}

	/**
	 * Retorna o custo desse servidor at� o momento
	 * 
	 * @return custo do servidor
	 */
	public int getCost() {
		return this.cost;
	}

}
