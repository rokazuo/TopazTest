package br.com.topaz.server;

import java.util.ArrayList;
import java.util.List;

/**
 * Classe que representa o balanceador de usu�rios nos servidores Cada usu�rio
 * novo ser� conectado ao servidor que tiver o maior tempo restante de vida,
 * pois esse servidor � que ter� o maior custo. Outro balanceamento feito � que
 * entre os servidores de maior custo restante, ser�o distribu�do os novos
 * usu�rios igualitariamente nos servidores para maximizar a performance de cada
 * servidor. Esse balanceamento n�o aumetar� o custo do servidor, j� que o tempo
 * de vida restante desses servidores j� est� cravado pelo usu�rio que tem o
 * maior tempo de vida restante dentro do servidor.
 * 
 */
public class Balancer {
	int ttask;
	int umax;
	int totalNumberOfCadidateEmptySlot = 0;

	/**
	 * Construtor da classe Balancer
	 * 
	 * @param ttask
	 *            custo de uma tarefa no servidor
	 * 
	 * @param umax
	 *            quantidade m�xima de usu�rios por servidor
	 * 
	 */
	public Balancer(int ttask, int umax) {
		this.ttask = ttask;
		this.umax = umax;
	}

	/**
	 * Aloca novos usu�rios aos servidores, realizando um balanceamento desses
	 * novos usu�rios nos servidores visando o menor custo total e ao mesmo
	 * tempo a melhor performance do servidor, distriuindo igualitariamente a
	 * quantidade de usu�rios por servidor de maior custo remanescente.
	 * 
	 * @param numberOfUsersToAlloc
	 *            quantidade de usu�rio novos a serem conectados nos servidores
	 * 
	 * @param serverList
	 *            lista atual de servidores existentes
	 * 
	 */
	public void allocateUsers(int numberOfUsersToAlloc, List<Server> serverList) {
		int numberOfUserAllocated = 0;
		// se existirem servidores rodando, tentar� balancear
		// os usu�rios nesses servidores
		if (serverList.size() > 0) {
			numberOfUserAllocated = allocateUsersInCurrentServers(
					numberOfUsersToAlloc, serverList);
		}
		// os usu�rios que n�o puderam ser conectados nos servidores atuais
		// ser�o direcionados para novos servidores
		if (numberOfUserAllocated != numberOfUsersToAlloc) {
			allocateUserInNewServers(numberOfUsersToAlloc
					- numberOfUserAllocated, serverList);
		}
	}

	/**
	 * Aloca novos usu�rios em novas inst�ncias de servidores
	 * 
	 * @param numberOfUsersToAlloc
	 *            quantidade de usu�rio novos a serem conectados nos servidores
	 * 
	 * @param serverList
	 *            lista atual de servidores existentes
	 * 
	 */
	public void allocateUserInNewServers(int numberOfUsersToAlloc,
			List<Server> serverList) {
		while (numberOfUsersToAlloc > 0) {
			Server server = new Server(ttask, umax);
			for (int i = 0; i < umax; i++) {
				server.allocateUser(1);
				numberOfUsersToAlloc--;
				if (numberOfUsersToAlloc == 0) {
					// se j� alocou todos os usu�rios requisitados
					// sai do loop de aloca��o
					break;
				}
			}
			serverList.add(server);
		}
	}

	/**
	 * Aloca novos usu�rios no servidores atuais, visando o menor custo e maior
	 * performance. Aloca os usu�rios no servidores atuais de maior custo
	 * remanescente visando assim o menor custo para esses novos usu�rios, j�
	 * que o servidor ter� que ficar rodando pelo tempo de vida/custo
	 * remanescente dele. A maior perfomance ser� alcan�ada distribuindo os
	 * novos usu�rio igualitariamente entre os servidores de maior custo
	 * remanescente
	 * 
	 * @param numberOfUsersToAlloc
	 *            quantidade de usu�rio novos a serem conectados nos servidores
	 * 
	 * @param serverList
	 *            lista atual de servidores existentes
	 * 
	 */
	public int allocateUsersInCurrentServers(int numberOfUsersToAlloc,
			List<Server> serverList) {
		// minimiza custo de servidores, selecionando os que ainda tem maior
		// tempo de vida remanescente
		List<Server> serverCandidateList = getServeCandidateList(
				numberOfUsersToAlloc, serverList);
		// maximiza performance, balanceando a quantidade de usu�rios em cada
		// servidor candidato a receber novos usu�rios
		int numberOfAllocatedUsers = balanceUsersInServers(
				numberOfUsersToAlloc, serverCandidateList);
		return numberOfAllocatedUsers;
	}

	/**
	 * Aloca novos usu�rios nos servidores canditados previamente selecionados
	 * fora desse m�todo. Ser� balanceado os novos usu�rios nesses servidores
	 * previamente selecionados visando uma m�dia de usu�rios por servidor
	 * iguais nos servidores previamente selecionados
	 * 
	 * @param numberOfUsersToAlloc
	 *            quantidade de usu�rio novos a serem conectados nos servidores
	 * 
	 * @param serverCandidateList
	 *            lista de servidores previamente selecionados de acordo com o
	 *            <p>
	 *            numberOfUsersToAlloc
	 *            </p>
	 * 
	 */
	public int balanceUsersInServers(int numberOfUsersToAlloc,
			List<Server> serverCandidateList) {
		// quantidade de usu�rios alocado
		int numberOfAllocatedUsers = 0;
		// quantidade de servidores que necessariamente precisar�o estar cheios
		int numberOfServersToBeFull = 0;
		// quantidade de usu�rios restante que precisam ser alocados
		int numberOfRemainingUsersToBeAlloc = numberOfUsersToAlloc;
		// quantidade de servidores sobrando para serem utilizados
		int numberOfRemainingServersToBeUsed = serverCandidateList.size();
		// quantidade total de vagas em todos os servidores
		int numberOfRemainingEmptySlot = totalNumberOfCadidateEmptySlot;
		// quantidade total de vagas em todos os servidores ap�s serem alocados
		// uma determinada quantidade de novos usu�rios
		int numberOfRemainingEmptySlotAfterAlloc = numberOfRemainingEmptySlot
				- numberOfUsersToAlloc;
		if (numberOfRemainingEmptySlotAfterAlloc < serverCandidateList.size()) {
			// se ap�s alocar todos os usu�rios a quantidade de vagas livres em
			// todos os servidores for menor que a quantidade de servidores,
			// significa que ter� necess�riamente uma quantidade de servidores
			// lotado de usu�rios
			numberOfServersToBeFull = serverCandidateList.size()
					- numberOfRemainingEmptySlotAfterAlloc;
		}
		// percorre a lista na ordem inversa para processar primeiro os
		// servidores que podem acomodar mais usu�rios. Esse crit�rio
		// foi garantido no m�todo getServeCandidateList
		for (int i = serverCandidateList.size() - 1; i >= 0; i--) {
			if (numberOfServersToBeFull > 0) {
				// lota os servidores que podem acomodar mais usu�rios
				int numberOfUserToAllocNow = serverCandidateList.get(i)
						.getNumberOfEmptySlot();
				numberOfAllocatedUsers += numberOfUserToAllocNow;
				numberOfRemainingEmptySlot -= numberOfUserToAllocNow;
				numberOfRemainingUsersToBeAlloc -= numberOfUserToAllocNow;
				serverCandidateList.get(i).allocateUser(numberOfUserToAllocNow);
				numberOfRemainingServersToBeUsed--;
				numberOfServersToBeFull--;
			} else {
				// distribui os usu�rios igualitariamente entre os servidores
				// remanescentes maximizando-se a performance mantendo-se uma
				// m�dia de usu�rios por servidor constante nos servidores

				// quantidade m�dida de vagas por servidor ap�s alocar os
				// usu�rios remanescentes nos servidores remanescentes
				int averageEmtpySlotAfterAlloc = (numberOfRemainingEmptySlot - numberOfRemainingUsersToBeAlloc)
						/ numberOfRemainingServersToBeUsed;
				// aloca a quantidade de usu�rio nesse servidor mantendo-se uma
				// m�dia remanescente de vaga por servidor
				// contante, maximizando-se assim a performance do servidor para
				// atender a parte do enunciado que diz
				// "Em contrapartida a capacidade e performance aumenta quando adicionamos mais servidores"
				int numberOfUserToBeAllocNow = serverCandidateList.get(i)
						.getNumberOfEmptySlot() - averageEmtpySlotAfterAlloc;
				// prote��o caso o c�lculo de usu�rio para ser alocado no
				// momento seja maior que o necess�rio da quantidade de usu�rio
				// remanescentes para serem alocados
				if (numberOfUserToBeAllocNow > (numberOfUsersToAlloc - numberOfAllocatedUsers)) {
					numberOfUserToBeAllocNow = (numberOfUsersToAlloc - numberOfAllocatedUsers);
				}
				serverCandidateList.get(i).allocateUser(
						numberOfUserToBeAllocNow);
				numberOfAllocatedUsers += numberOfUserToBeAllocNow;
			}
			// se j� alocou todos os usu�rio, encerra o loop de aloca��o
			if (numberOfAllocatedUsers == numberOfUsersToAlloc) {
				break;
			}
		}
		return numberOfAllocatedUsers;
	}

	/**
	 * Seleciona os servidores de maiores custo remanescente para alocar os
	 * novos usu�rios. Retorna todos os servidores de maiores custos
	 * remanescentes, mesmo que j� tenha sido encontrado um servidor de maior
	 * custo remanescente que tenha vagas suficientes para a quantidade de novos
	 * usu�rios a serem alocados. Isso � necess�rio, pois o algoritmo de
	 * balanceamento de novos usu�rios nos servidores ir� manter uma m�dia de
	 * usu�rio por servidor constante, para maximizar a performance
	 * 
	 * @param numberOfUsersToAlloc
	 *            quantidade de usu�rio novos a serem conectados nos servidores
	 * 
	 * @return servidores de maiores custos/tempo de vida remanescentes
	 * 
	 */
	public List<Server> getServeCandidateList(int numberOfUsersToAlloc,
			List<Server> serverList) {
		List<Server> serverCandidateList = new ArrayList<Server>();
		// percorrer� a lista de traz para frente, pois os �ltimos servers
		// adicionados ter�o o maior tempo de vida, ou seja,
		// o maior custo remanescente. Ser�o selecionados esses servidores
		// candidatos a serem utilizados pelos novos usu�rios,
		// minimizando assim o custo de utiliza��o dos servidores pegando os
		// �ltimos servidores da lista.
		// Um detalhe � que se tiverem servidores com slots livres e com mesmo
		// tempo alto de vida remanescente, ser�o servidores candidatos
		// selecionados, para serem balanceado (em outro m�todo) as aloca��o dos
		// usu�rios entres esses servidores candidatos para maximaxar a
		// performance, para atender a parte do enunciado que diz
		// "Em contrapartida a capacidade e performance aumenta quando adicionamos mais servidores"
		totalNumberOfCadidateEmptySlot = 0;
		int highestServerRemainingTimeLife = serverList.get(
				serverList.size() - 1).getRemainingTimeLife();
		int highestNumberOfEmptySlot = 0;
		for (int i = serverList.size() - 1; i >= 0; i--) {
			Server serverCandidateToBeSelected = serverList.get(i);
			boolean isToAddServer = false;
			boolean isToCheckExit = false;
			// o servidor tem que ter vaga dispon�vel para ser um servidor
			// canditado a receber novos usu�rios
			if (serverCandidateToBeSelected.getNumberOfEmptySlot() > 0) {
				// seleciona os servidores que tiverem os maiores tempo
				// de vida remanescente, pois ser� balanceado entre eles os
				// usu�rios para maximizar a performance. Seleciona tamb�m
				// qualquer servidor se for necess�rio para completar de alocar
				// os usu�rios remanescentes
				if (highestServerRemainingTimeLife == serverCandidateToBeSelected
						.getRemainingTimeLife()) {
					isToAddServer = true;
				} else if (totalNumberOfCadidateEmptySlot < numberOfUsersToAlloc) {
					// seleciona mais servidores mesmo que n�o tenham os maiores
					// tempo de vida remanescente, para que assim possa ser
					// alocado todos os usu�rios
					isToAddServer = true;
					isToCheckExit = true;
				}
				if (isToAddServer) {
					// servidor com maior empty slot deve ficar no fim da lista
					// para assim facilitar o algoritmo de balanceamento que
					// manter� a m�dia de usu�rio por servidor contante
					if (highestNumberOfEmptySlot > serverCandidateToBeSelected
							.getNumberOfEmptySlot()) {
						serverCandidateList.add(0, serverCandidateToBeSelected);
					} else {
						serverCandidateList.add(serverCandidateToBeSelected);
						highestNumberOfEmptySlot = serverCandidateToBeSelected
								.getNumberOfEmptySlot();
					}
					totalNumberOfCadidateEmptySlot += serverCandidateToBeSelected
							.getNumberOfEmptySlot();
				}
				// se j� selecionou a quantidade de servidores o suficiente
				// para a quantidade de novos usu�rios pode encenrrar o
				// m�todo
				if (isToCheckExit
						&& (totalNumberOfCadidateEmptySlot >= numberOfUsersToAlloc)) {
					break;
				}
			}
		}
		return serverCandidateList;
	}

	/**
	 * Retorna a quantidade total de vagas nos servidores candidatos a receberem
	 * novos usu�rios
	 * 
	 * @return quantidade total de vagas nos servidores candidatos a receberem
	 *         novos usu�rios
	 * 
	 */
	public int getTotalNumberOfCadidateEmptySlot() {
		return this.totalNumberOfCadidateEmptySlot;
	}
}
