package br.com.topaz.server;

import java.util.ArrayList;
import java.util.List;

/**
 * Classe que realiza a mecanica de funcionamento das classes Server e Balancer
 * processando o input e output txt como uma lista java.
 * 
 */
// Se fosse para ter performance no processamento do txt, a medida que fosse
// lido uma linha, seria ela processada e escrito o resultado numa linha do
// output.txt, pois assim a lista n�o seria percorrida duas vezes. Fiz da
// forma que est� para que o c�digo do unit test n�o dependa do txt.
public class Engine {

	/**
	 * Processa o input.txt como uma lista java e retorna uma lista de string a
	 * ser escrita no ouput.txt.
	 * 
	 * @param inputIntegerList
	 *            input.txt no formato de uma lista de inteiros
	 * 
	 * @return lista de String para ser escrito no output.txt
	 * 
	 */
	public static List<String> processInput(List<Integer> inputIntegerList) {
		// retorno deste m�todos que lista de string para ser escrita no
		// output.txt. Lista que ser� montada com os usu�rios ativos
		// em cada servidor
		List<String> outputStringList = new ArrayList<String>();
		// a primeira linha � o custo de uma tarefa no servidor
		int ttask = inputIntegerList.remove(0);
		// a segunda linha � a capacidade total de usu�rios por servidor
		int umax = inputIntegerList.remove(0);
		// lista dos servidores
		List<Server> serverList = new ArrayList<Server>();
		// instanciando o balanceador de usu�rios por servidor
		Balancer balancer = new Balancer(ttask, umax);
		// custo total de todos os servidores que ser�o utilizados
		int totalCost = 0;
		// enquanto houver linhas do input.txt a serem processadas e/ou
		// servidores
		// rodando
		while (inputIntegerList.size() > 0 || serverList.size() > 0) {
			// linha para ser escrita no ouput.txt
			StringBuilder ouputStrBuilder = new StringBuilder();
			// armazena a quantidade de usu�rios na linha do input.txt a serem
			// alocados
			int numberOfUsersToAlloc = inputIntegerList.size() > 0 ? inputIntegerList
					.remove(0) : 0;
			// se tiver usu�rio a ser alocado, aloca ele a um servidor atrav�s
			// do balanceador, que � a classe Balancer
			if (numberOfUsersToAlloc > 0) {
				balancer.allocateUsers(numberOfUsersToAlloc, serverList);
			}

			// cria uma lista tempor�ria de servidores a serem removidos por n�o
			// ter usu�rios conectados
			List<Server> serverHasNoUserList = new ArrayList<Server>();
			for (Server server : serverList) {
				if (ouputStrBuilder.length() > 0) {
					ouputStrBuilder.append(",");
				}
				ouputStrBuilder.append(server.getNumberOfActiveUser());

				// realiza o trabalho do servidor em uma unidade b�sica de
				// simula��o (tick)
				server.work();

				// Ap�s o servidor trabalhar na execu��o de uma tarefa
				// dos usu�rios conectados, verifica a necessidade de
				// remov�-lo ao fim desse loop.
				if (server.hasNoUser()) {
					serverHasNoUserList.add(server);
				}
			}

			// adiciona uma linha a ser escrita no output.txt
			outputStringList.add(ouputStrBuilder.toString());

			// remove os servidores sem usu�rios ativos
			// totalizando o custo de vida desse servidor
			for (Server serverHasNoUser : serverHasNoUserList) {
				totalCost += serverHasNoUser.getCost();
				serverList.remove(serverHasNoUser);
			}
		}
		outputStringList.add("0");
		outputStringList.add(Integer.toString(totalCost));
		return outputStringList;
	}
}
