package br.com.topaz.server;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Solution {

	public static void main(String[] args) throws IOException {
		System.out.println("In�cio");
		// n�o tem uma boa performance de c�digo ler/escrever do arquivo e
		// armazenar numa lista tempor�ria, pois a lista ser� percorrida duas
		// vezes (ao ler/escrever no arquivo e ao montar a lista). Mas fiz isso
		// para facilitar o unit test da Engine.
		List<String> outputStringList = Engine.processInput(getFromInputFile());
		writeToOutputFile(outputStringList);
		System.out.println("Fim");
	}

	private static void writeToOutputFile(List<String> outputStringList) {
		BufferedWriter writer = null;
		try {
			writer = new BufferedWriter(new FileWriter("output.txt"));
			writer.write("");
			boolean isFirstLine = true;
			for (String outputString : outputStringList) {
				if (!isFirstLine) {
					writer.newLine();
				} else {
					isFirstLine = false;
				}
				writer.append(outputString);
			}
		} catch (IOException e) {
			System.out.println("Error writing to file: " + e.getMessage());
		} finally {
			if (writer != null) {
				try {
					writer.close();
				} catch (IOException e) {
					System.out.println("Error on closing buffer: "
							+ e.getMessage());
				}
			}
		}
	}

	private static List<Integer> getFromInputFile() {
		BufferedReader br = null;
		List<Integer> inputIntegerList = new ArrayList<Integer>();
		try {
			br = new BufferedReader(new FileReader("input.txt"));
			String line;
			while ((line = br.readLine()) != null) {
				inputIntegerList.add(Integer.parseInt(line));
			}
			return inputIntegerList;
		} catch (Exception e) {
			System.out.println("Error reading file: " + e.getMessage());
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					System.out.println("Error on closing buffer: "
							+ e.getMessage());
				}
			}
		}
		return inputIntegerList;
	}
}